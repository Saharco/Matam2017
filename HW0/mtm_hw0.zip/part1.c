#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
bool initializie_arr(int *arr, int len);
int get_power_of_2(int num);
int main() {
	int nums_amount=0, power=0, exp_sum=0;
	bool size_flag;
	printf("Enter size of input:\n");
	size_flag = scanf("%d", &nums_amount);
	if((!size_flag) || nums_amount<=0) {
		printf("Invalid size\n");
		return 0;
	}
	int *arr = malloc(sizeof(int) * nums_amount);
	if (arr == NULL) return 0;
	printf("Enter numbers:\n");
	if(!initializie_arr(arr, nums_amount)) {
		free(arr);
		return 0;
	}
	for(int i=0; i<nums_amount; i++) {
		power = get_power_of_2(*(arr+i));
		if(power!=-1) {
			printf("The number %d is a power of 2: %d = 2^%d\n", *(arr+i), *(arr+i), power);
			exp_sum+=power;
		}
	}
	free(arr);
	printf("Total exponent sum is %d\n", exp_sum);
	return 0;
}
bool initializie_arr(int *arr, int len) {
	for(int i=0; i<len; i++) {
		if(scanf("%d", (arr+i))!=1) {
			printf("Invalid number\n");
			return false;
		}
	}
	return true;
}
int get_power_of_2(int num) {
	if(num<=0) return -1;
	int count=0;
	while(num%2==0) {
		count++;
		num=num/2;
	}
	if(num==1) return count;
	return -1;
}
