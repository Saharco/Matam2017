#include <stdio.h>
#include <assert.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include "test_utilities.h"
#include "../Escaper.h"
#include "../Room.h"
#include "../mtm_ex3.h"

static bool escaperCreateTest() {
	/*ORDER OF CREATE:
	* email, faculty, skill level */
	EscaperResult res;
	ASSERT_TEST(escaperCreate(&res, "a52d@edtr", ARCHITECTURE, 11)==NULL);
	ASSERT_TEST(res == ESCAPER_INVALID_PARAMETER);
	ASSERT_TEST(escaperCreate(&res, NULL, ARCHITECTURE, 11)==NULL);
	ASSERT_TEST(res == ESCAPER_NULL_PARAMETER);
	ASSERT_TEST(escaperCreate(NULL, "a52dwedtr", ARCHITECTURE, 1)==NULL);
	ASSERT_TEST(escaperCreate(NULL, "a52d@ed@r", ARCHITECTURE, 10)==NULL);
	ASSERT_TEST(escaperCreate(NULL, "a52d@edtr", ARCHITECTURE, -1)==NULL);
	ASSERT_TEST(escaperCreate(NULL, "a52d@edtr", UNKNOWN, 1)==NULL);
	ASSERT_TEST(escaperCreate(NULL, "",ARCHITECTURE, 7)==NULL);
	ASSERT_TEST(escaperCreate(NULL, "a52d@edtr", ARCHITECTURE, 0)==NULL);
	Escaper escaper = escaperCreate(&res, "escape@gmail.com", BIOLOGY, 6);
	ASSERT_TEST(escaper != NULL);
	ASSERT_TEST(res == ESCAPER_SUCCESS);
	escaperDestroy(escaper);
	return true;
}

static bool escaperDestroyTest() {
	Escaper escaper1 = escaperCreate(NULL, "matam@technion", BIOLOGY, 10);
	ASSERT_TEST(escaperDestroy(escaper1) == ESCAPER_SUCCESS);
	Escaper escaper2 = escaperCreate(NULL, "matam1technion", BIOLOGY, 10);
	ASSERT_TEST(escaperDestroy(escaper2) == ESCAPER_NULL_PARAMETER);
	Escaper escaper3 = escaperCreate(NULL, "matam@technion",BIOLOGY , 0);
	ASSERT_TEST(escaperDestroy(escaper3) == ESCAPER_NULL_PARAMETER);
	Escaper escaper4 = escaperCreate(NULL, "@technion.ac.il", CHEMISTRY, 1);
	ASSERT_TEST(escaperDestroy(escaper4) == ESCAPER_SUCCESS);
	return true;
}

static bool escaperCopyTest() {
	Escaper escaper = escaperCreate(NULL, "matam@technion.ac.il", -1 ,7);
	Escaper escaper_copy = escaperCopy(escaper);
	ASSERT_TEST(escaper_copy == NULL);;
	escaper = escaperCreate(NULL, "matam@te@chnion.ac.il", COMPUTER_SCIENCE, 6);
	escaper_copy = escaperCopy(escaper);
	ASSERT_TEST(escaper_copy == NULL);
	escaperDestroy(escaper_copy);
	escaperDestroy(escaper);
	escaper = escaperCreate(NULL, "matam@technion.ac.il", COMPUTER_SCIENCE, 17);
	escaper_copy = escaperCopy(escaper);
	ASSERT_TEST(escaper_copy == NULL);
	escaperDestroy(escaper_copy);
	escaperDestroy(escaper);
	escaper = escaperCreate(NULL, "matam@technion.ac.il", COMPUTER_SCIENCE, 8);
	escaper_copy = escaperCopy(escaper);
	ASSERT_TEST(escaper_copy != NULL);
	escaperDestroy(escaper_copy);
	escaperDestroy(escaper);
	return true;
}

static bool ecaperGetEmailTest() {
	char* email;
	Escaper escaper = escaperCreate(NULL, "Hello@world", PHYSICS, 5);
	ASSERT_TEST(escaperGetEmail(escaper, &email) == ESCAPER_SUCCESS);
	ASSERT_TEST(strcmp(email, "Hello@world") == 0);
	escaperDestroy(escaper);
	escaper = escaperCreate(NULL, "Hello@world", PHYSICS, 55);
	ASSERT_TEST(escaperGetEmail(escaper, &email) == ESCAPER_NULL_PARAMETER);
	return true;
}

static bool escaperGetFacultyTest() {
	TechnionFaculty faculty;
	Escaper escaper = escaperCreate(NULL, "Hello@world", PHYSICS, 0);
	ASSERT_TEST(escaperGetFaculty(escaper, &faculty) == ESCAPER_NULL_PARAMETER);
	escaper = escaperCreate(NULL, "Hello@world", -1, 5);
	ASSERT_TEST(escaperGetFaculty(escaper, &faculty) == ESCAPER_NULL_PARAMETER);
	escaper = escaperCreate(NULL, "Hello.world", PHYSICS, 5);
	ASSERT_TEST(escaperGetFaculty(escaper, &faculty) == ESCAPER_NULL_PARAMETER);
	escaper = escaperCreate(NULL, "Hello@world@", PHYSICS, 5);
	ASSERT_TEST(escaperGetFaculty(escaper, &faculty) == ESCAPER_NULL_PARAMETER);
	escaper = escaperCreate(NULL, "Hello@world", PHYSICS, 5);
	ASSERT_TEST(escaperGetFaculty(escaper, &faculty) == ESCAPER_SUCCESS);
	ASSERT_TEST(faculty == PHYSICS);
	escaperDestroy(escaper);
	return true;
}

static bool escaperGetSkillLevelTest() {
	int skill_level;
	Escaper escaper = escaperCreate(NULL, "Hello@world", PHYSICS, 0);
	ASSERT_TEST(escaperGetSkillLevel(escaper, &skill_level) ==
	ESCAPER_NULL_PARAMETER);
	escaper = escaperCreate(NULL, "Hello@world", -1, 5);
	ASSERT_TEST(escaperGetSkillLevel(escaper, &skill_level) ==
	ESCAPER_NULL_PARAMETER);
	escaper = escaperCreate(NULL, "Hello.world", PHYSICS, 5);
	ASSERT_TEST(escaperGetSkillLevel(escaper, &skill_level) ==
	ESCAPER_NULL_PARAMETER);
	escaper = escaperCreate(NULL, "Hello@world@", PHYSICS, 5);
	ASSERT_TEST(escaperGetSkillLevel(escaper, &skill_level) ==
	ESCAPER_NULL_PARAMETER);
	escaper = escaperCreate(NULL, "Hello@world", PHYSICS, 5);
	ASSERT_TEST(escaperGetSkillLevel(escaper, &skill_level) ==
	ESCAPER_SUCCESS);
	ASSERT_TEST(skill_level == 5);
	escaperDestroy(escaper);
	return true;
}

static bool escaperMakeReservationTest() {
	Escaper escaper1 = escaperCreate(NULL, "matam@technion.ac.il", PHYSICS, 1);
	Room room = roomCreate(NULL, 1, 4, 1, 1, "08-20");
	ASSERT_TEST(escaperMakeReservation(escaper1, room, PHYSICS, 3, "01-10")
	== ESCAPER_SUCCESS);
	ASSERT_TEST(roomHasReservations(room));
	ASSERT_TEST(escaperMakeReservation(escaper1, room, PHYSICS, 5, "01-10")
	== ESCAPER_IN_ROOM);
	Escaper escaper2 = escaperCreate(NULL, "a@1", BIOLOGY, 3);
	ASSERT_TEST(escaperMakeReservation(escaper2, room, BIOLOGY, 1, "00-16")
	== ESCAPER_SUCCESS);
	ASSERT_TEST(escaperMakeReservation(escaper1, room, PHYSICS, 5, "00-16")
	== ESCAPER_RESERVED_ROOM);
	roomDestroy(room);
	escaperDestroy(escaper1);
	escaperDestroy(escaper2);
	return true;
}

static bool escaperReservationsAmountTest() {
	Escaper escaper = escaperCreate(NULL, "matam@technion.ac.il", PHYSICS ,1);
	int amount = -1;
	escaperReservationsAmount(escaper, &amount);
	ASSERT_TEST(amount == 0);
	Room room = roomCreate(NULL, 1, 4, 1, 1, "08-20");
	escaperMakeReservation(escaper, room, PHYSICS, 3, "00-10");
	escaperReservationsAmount(escaper, &amount);
	ASSERT_TEST(amount == 1);
	escaperMakeReservation(escaper, room, PHYSICS, 3, "00-12");
	escaperReservationsAmount(escaper, &amount);
	ASSERT_TEST(amount == 2);
	escaperMakeReservation(escaper, room, PHYSICS, 3, "01-10");
	escaperReservationsAmount(escaper, &amount);
	ASSERT_TEST(amount == 3);
	roomDestroy(room);
	escaperDestroy(escaper);
	return true;
}

static bool escaperNextDayTest() {
	Escaper escaper = escaperCreate(NULL, "matam@technion.ac.il", PHYSICS ,1);
	Room room = roomCreate(NULL, 1, 4, 1, 1, "08-20");
	int amount = -1;
	escaperMakeReservation(escaper, room, PHYSICS, 3, "00-10");
	escaperMakeReservation(escaper, room, PHYSICS, 3, "00-12");
	escaperMakeReservation(escaper, room, PHYSICS, 3, "01-10");
	escaperMakeReservation(escaper, room, PHYSICS, 3, "01-16");
	escaperMakeReservation(escaper, room, PHYSICS, 3, "02-08");
	roomNextDay(room);
	escaperNextDay(escaper);
	escaperReservationsAmount(escaper, &amount);
	ASSERT_TEST(amount == 3);
	roomNextDay(room);
	escaperNextDay(escaper);
	escaperReservationsAmount(escaper, &amount);
	ASSERT_TEST(amount == 1);
	roomNextDay(room);
	escaperNextDay(escaper);
	escaperReservationsAmount(escaper, &amount);
	ASSERT_TEST(amount == 0);
	roomDestroy(room);
	escaperDestroy(escaper);
	return true;
}

static bool escaperIsBusyTest() {
	Escaper escaper = escaperCreate(NULL, "matam@technion.ac.il", PHYSICS, 1);
	Room room = roomCreate(NULL, 1, 4, 1, 1, "08-20");
	escaperMakeReservation(escaper, room, PHYSICS, 3, "00-10");
	escaperMakeReservation(escaper, room, PHYSICS, 3, "00-12");
	escaperMakeReservation(escaper, room, PHYSICS, 3, "01-10");
	escaperMakeReservation(escaper, room, PHYSICS, 3, "01-16");
	escaperMakeReservation(escaper, room, PHYSICS, 3, "02-08");
	ASSERT_TEST(escaperIsBusy(escaper, 10));
	ASSERT_TEST(!escaperIsBusy(escaper, 8));
	escaperNextDay(escaper);
	ASSERT_TEST(escaperIsBusy(escaper,10));
	ASSERT_TEST(!escaperIsBusy(escaper, 12));
	escaperNextDay(escaper);
	ASSERT_TEST(!escaperIsBusy(escaper, 10));
	ASSERT_TEST(escaperIsBusy(escaper, 8));
	roomDestroy(room);
	escaperDestroy(escaper);
	return true;
}

static bool escaperRemoveReservationTest() {
	Escaper escaper = escaperCreate(NULL, "matam@technion.ac.il", PHYSICS, 1);
	Room room = roomCreate(NULL, 1, 4, 1, 1, "08-20");
	escaperMakeReservation(escaper, room, PHYSICS, 3, "00-10");
	escaperMakeReservation(escaper, room, PHYSICS, 3, "00-12");
	escaperMakeReservation(escaper, room, PHYSICS, 3, "01-10");
	escaperMakeReservation(escaper, room, PHYSICS, 3, "01-16");
	escaperMakeReservation(escaper, room, PHYSICS, 3, "02-08");
	ASSERT_TEST(escaperRemoveReservation(escaper, 8) ==
	ESCAPER_INVALID_PARAMETER);
	ASSERT_TEST(escaperRemoveReservation(escaper, 10) == ESCAPER_SUCCESS);
	escaperNextDay(escaper);
	ASSERT_TEST(escaperRemoveReservation(escaper, 10) == ESCAPER_SUCCESS);
	escaperNextDay(escaper);
	ASSERT_TEST(escaperRemoveReservation(escaper, 8) == ESCAPER_SUCCESS);
	roomDestroy(room);
	escaperDestroy(escaper);
	return true;
}
int main(int argv, char** arc) {
	RUN_TEST(escaperCreateTest);
	RUN_TEST(ecaperGetEmailTest);
	RUN_TEST(escaperGetFacultyTest);
	RUN_TEST(escaperGetSkillLevelTest);
	RUN_TEST(escaperMakeReservationTest);
	RUN_TEST(escaperReservationsAmountTest);
	RUN_TEST(escaperNextDayTest);
	RUN_TEST(escaperIsBusyTest);
	RUN_TEST(escaperRemoveReservationTest);
	RUN_TEST(escaperCopyTest);
	RUN_TEST(escaperDestroyTest);
	return 0;
}
