#include <stdio.h>
#include <assert.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include "test_utilities.h"
#include "../Room.h"
#include "../mtm_ex3.h"

#define NOT_INITIALIZED -1

static bool reservationCreateTest() {
	ReservationResult r;
	ASSERT_TEST(reservationCreate
	(&r, "no!", 1, BIOLOGY, 4, 0, 23, 1, "00-01", false) == NULL);
	ASSERT_TEST(r == RESERVATION_INVALID_PARAMETER);
	ASSERT_TEST(reservationCreate
	(&r, "@yes!@", 1, BIOLOGY, 4, 0, 23, 1, NULL, false) == NULL);
	ASSERT_TEST(r == RESERVATION_NULL_PARAMETER);
	ASSERT_TEST(reservationCreate
	(NULL, "@yes!@", 1, BIOLOGY, 4, 0, 23, 1, "00-01", false) == NULL);
	ASSERT_TEST(reservationCreate
	(&r, "", 1, BIOLOGY, 4, 0, 23, 1, "00-01", false) == NULL);
	ASSERT_TEST(reservationCreate
	(&r, "1@a", -1, BIOLOGY, 4, 0, 23, 1, "00-01", false) == NULL);
	ASSERT_TEST(reservationCreate
	(&r, "1@a", 1, BIOLOGY, -1, 0, 23, 1, "00-01", false) == NULL);
	ASSERT_TEST(reservationCreate
	(&r, "1@a", 1, UNKNOWN, 4, 0, 23, 1, "00-01", false) == NULL);
	ASSERT_TEST(reservationCreate
	(&r, "1@a", 1, BIOLOGY, 3, 0, 23, 1, "00-01", false) == NULL);
	ASSERT_TEST(reservationCreate
	(&r, "1@a", 1, BIOLOGY, 4, -1, 23, 1, "00-01", false) == NULL);
	ASSERT_TEST(reservationCreate
	(&r, "1@a", 1, BIOLOGY, 4, 24, 23, 1, "00-01", false) == NULL);
	ASSERT_TEST(reservationCreate
	(&r, "1@a", 1, BIOLOGY, 4, 12, 10, 1, "00-01", false) == NULL);
	ASSERT_TEST(reservationCreate
	(&r, "1@a", 1, BIOLOGY, 4, 0, -1, 1, "00-01", false) == NULL);
	ASSERT_TEST(reservationCreate
	(&r, "1@a", 1, BIOLOGY, 4, 10, 5, 1, "00-01", false) == NULL);
	ASSERT_TEST(reservationCreate
	(&r, "1@a", 1, BIOLOGY, 4, 0, 25, 1, "00-01", false) == NULL);
	ASSERT_TEST(reservationCreate
	(&r, "1@a", 1, BIOLOGY, 4, 0, 23, 1, "", false) == NULL);
	ASSERT_TEST(reservationCreate
	(&r, "1@a", 1, BIOLOGY, 4, 0, 23, 1, "00x01", false) == NULL);
	ASSERT_TEST(reservationCreate
	(&r, "1@a", 1, BIOLOGY, 4, 0, 23, 1, "00-25", false) == NULL);
	Reservation reservation = reservationCreate(NULL, "barvaz@gad.ol", 1,
	PHYSICS, 4, 8, 20, 3, "03-10", false);
	ASSERT_TEST(reservation != NULL);
	reservationDestroy(reservation);
	reservation = reservationCreate(NULL, "barvaz@gad.ol", 1,
	PHYSICS, 4, 8, 20, 3, "365-10", false);
	ASSERT_TEST(reservation != NULL);
	reservationDestroy(reservation);
	reservation = reservationCreate(NULL, "barvaz@gad.ol", 1,
	PHYSICS, 4, 0, 20, 3, "365-0", false);
	ASSERT_TEST(reservation != NULL);
	reservationDestroy(reservation);
	return true;
}

static bool reservationDestroyTest() {
	Reservation reservation = reservationCreate(NULL, "best@r", 43,
	COMPUTER_SCIENCE, 40, 8, 20, 3, "01-10", false);
	ASSERT_TEST(reservationDestroy(reservation) == RESERVATION_SUCCESS);
	reservation = reservationCreate(NULL, "best", 43, COMPUTER_SCIENCE,
	40, 8, 20, 3, "01-10", false);
	ASSERT_TEST(reservationDestroy(reservation) == RESERVATION_NULL_PARAMETER);
	return true;
}

static bool reservationCopyTest() {
	int id = 0;
	char* email = NULL;
	Reservation reservation = reservationCreate(NULL, "best@r", 43,
	COMPUTER_SCIENCE, 40, 5, 20, 3, "100-06", true);
	Reservation reservation_copy = reservationCopy(reservation);
	ASSERT_TEST(!reservationIsToday(reservation_copy));
	ASSERT_TEST(reservationHoursLeft(reservation_copy) == 2406);
	ASSERT_TEST(reservationGetHour(reservation_copy) == 6);
	ASSERT_TEST(reservationGetPrice(reservation_copy) == 90);
	ASSERT_TEST(reservationGetPeople(reservation_copy) == 3);
	reservationGetRoomId(reservation_copy, &id);
	ASSERT_TEST(id == 43);
	reservationGetEscaperEmail(reservation_copy, &email);
	ASSERT_TEST(strcmp(email, "best@r") == 0);
	reservationNextDay(reservation);
	ASSERT_TEST(!reservationIsToday(reservation_copy));
	reservationDestroy(reservation);
	reservationDestroy(reservation_copy);
	return true;
}

static bool reservationNextDayTest() {
	Reservation reservation = reservationCreate(NULL, "barvaz@gad.ol", 1,
	PHYSICS, 4, 8, 20, 3, "02-10", false);
	ASSERT_TEST(reservationNextDay(reservation)==RESERVATION_SUCCESS);
	ASSERT_TEST(!reservationIsToday(reservation));
	ASSERT_TEST(reservationNextDay(reservation)==RESERVATION_SUCCESS);
	ASSERT_TEST(reservationIsToday(reservation));
	reservationDestroy(reservation);
	reservation = reservationCreate(NULL, "barvaz@gad.ol", 1, PHYSICS,
	4, 8, 20, 3, "00-10", false);
	ASSERT_TEST(reservationNextDay(reservation)==RESERVATION_SUCCESS);
	ASSERT_TEST(reservationIsToday(reservation));
	reservationDestroy(reservation);
	return true;
}

static bool reservationIsTodayTest() {
	Reservation reservation = reservationCreate(NULL, "barvaz@gad.ol", 1,
	PHYSICS, 4, 8, 20, 3, "03-10", false);
	ASSERT_TEST(!reservationIsToday(reservation));
	reservationDestroy(reservation);
	reservation = reservationCreate(NULL, "barvaz@gad.ol", 1, PHYSICS,
	4, 8, 20, 3, "00-10", false);
	ASSERT_TEST(reservationIsToday(reservation));
	reservationDestroy(reservation);
	return true;
}

static bool reservationHoursLeftTest() {
	Reservation reservation = reservationCreate(NULL, "barvaz@gad.ol", 1,
	PHYSICS, 4, 0, 23, 3, "01-00", false);
	ASSERT_TEST(reservationHoursLeft(reservation) == 24);
	reservationDestroy(reservation);
	reservation = reservationCreate(NULL, "barvaz@gad.ol", 1, PHYSICS,
	4, 8, 20, 3, "03-10", false);
	ASSERT_TEST(reservationHoursLeft(reservation) == 82);
	reservationDestroy(reservation);
	reservation = reservationCreate(NULL, "barvaz@gad.ol", 1, PHYSICS,
	4, 0, 23, 3, "00-00", false);
	ASSERT_TEST(reservationHoursLeft(reservation) == 0);
	reservationDestroy(reservation);
	return true;
}

static bool reservationGetHourTest() {
	Reservation reservation = reservationCreate(NULL, "barvaz@gad.ol", 1,
	PHYSICS, 4, 8, 20, 3, "03-10", false);
	ASSERT_TEST(reservationGetHour(reservation)==10);
	reservationDestroy(reservation);
	reservation = reservationCreate(NULL, "barvaz@gad.ol", 1, PHYSICS,
	4, 0, 20, 3, "03-01", false);
	ASSERT_TEST(reservationGetHour(reservation)==1);
	reservationDestroy(reservation);
	reservation = reservationCreate(NULL, "barvaz@gad.ol", 1, PHYSICS,
	4, 8, 20, 3, "03-21", false);
	ASSERT_TEST(reservationGetHour(reservation)==RESERVATION_ILLEGAL);
	return true;
}

static bool reservationGetPriceTest() {
	Reservation reservation = reservationCreate(NULL, "Hello@mata.mm", 1,
	PHYSICS, 40, 8, 20, 3, "03-10", false);
	ASSERT_TEST(reservationGetPrice(reservation) == 120);
	reservationDestroy(reservation);
	reservation = reservationCreate(NULL, "Hello@mata.mm", 1, PHYSICS,
	40, 8, 20, 3, "03-10", true);
	ASSERT_TEST(reservationGetPrice(reservation) == 90);
	reservationDestroy(reservation);
	return true;
}

static bool reservationGetPeopleTest() {
	Reservation reservation = reservationCreate(NULL, "Hello@mata.mm", 1,
	PHYSICS, 40, 8, 20, 3, "03-10", false);
	ASSERT_TEST(reservationGetPeople(reservation) == 3);
	reservationDestroy(reservation);
	return true;
}

static bool reservationGetRoomIdTest() {
	Reservation reservation = reservationCreate(NULL, "Hello@mata.mm", 43,
	PHYSICS, 40, 8, 20, 3, "03-10", false);
	int id = 0;
	reservationGetRoomId(reservation, &id);
	ASSERT_TEST(id == 43);
	reservationDestroy(reservation);
	return true;
}

static bool reservationGetEscaperEmailTest() {
	char* email = NULL;
	Reservation reservation = reservationCreate(NULL, "Hello@mata.mm", 43,
	PHYSICS, 40, 8, 20, 3, "03-10", false);
	reservationGetEscaperEmail(reservation, &email);
	ASSERT_TEST(strcmp(email, "Hello@mata.mm") == 0);
	reservationDestroy(reservation);
	return true;
}

static bool reservationIsDiscountedTest() {
	Reservation reservation = reservationCreate(NULL, "Hello@mata.mm", 43,
	PHYSICS, 40, 8, 20, 3, "03-10", false);
	ASSERT_TEST(!reservationIsDiscounted(reservation));
	reservationDestroy(reservation);
	reservation = reservationCreate(NULL, "Hello@mata.mm", 43, PHYSICS,
	40, 8, 20, 3, "03-10", true);
	ASSERT_TEST(reservationIsDiscounted(reservation));
	reservationDestroy(reservation);
	return true;
}

static bool reservationGetDayTest() {
	Reservation reservation1 = reservationCreate(NULL, "no!", 1, BIOLOGY, 4,
	0, 23, 1, "00-01", false);
	ASSERT_TEST(reservationGetDay(reservation1) == RESERVATION_ILLEGAL);
	Reservation reservation2 = reservationCreate(NULL, "Hello@mata.mm", 43, PHYSICS,
	40, 8, 20, 3, "03-10", true);
	ASSERT_TEST(reservationGetDay(reservation2) ==  3);
	reservationDestroy(reservation1);
	reservationDestroy(reservation2);
	return true;
}

int main(int argv, char** arc) {
	RUN_TEST(reservationCreateTest);
	RUN_TEST(reservationGetHourTest);
	RUN_TEST(reservationGetPriceTest);
	RUN_TEST(reservationGetPeopleTest);
	RUN_TEST(reservationGetRoomIdTest);
	RUN_TEST(reservationGetEscaperEmailTest);
	RUN_TEST(reservationIsDiscountedTest);
	RUN_TEST(reservationIsTodayTest);
	RUN_TEST(reservationHoursLeftTest);
	RUN_TEST(reservationNextDayTest);
	RUN_TEST(reservationCopyTest);
	RUN_TEST(reservationGetDayTest);
	RUN_TEST(reservationDestroyTest);
	return 0;
}
