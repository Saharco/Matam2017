#include "test_utilities.h"
#include "../list_mtm/list_mtm1.h"
#include <stdio.h>
#include <assert.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>

/*static void printStringList (List list) {
	assert(list);
	char* current = ((char*) listGetFirst(list));
	printf("\n");
	while (current) {
		printf("%s\n", current);
		current = (char*) listGetNext(list);
	}

}*/
static ListElement copyString(ListElement str){
	assert(str);
	char* copy = malloc(strlen(str)+1);
	return copy != NULL ? strcpy(copy, str) : NULL;
}

static void freeString(ListElement str){
	free(str);
}

static bool isLongerThanString(ListElement str,ListFilterKey key) {
    return strlen((char*)str) > *(int*)key;
}

static int diffLengthString(ListElement str1, ListElement str2) {
	assert(str1 && str2);
	return (strlen((char*)str1) - strlen((char*)str2));
}

static ListElement copyInteger(ListElement num){
	assert(num);
	int* copy = malloc(sizeof(int));
	if(!copy)
		return NULL;
	*copy = *((int*)num);
	return copy;
}

static void freeInteger(ListElement num){
	free((int*)num);
}

static bool isBiggerThanInteger(ListElement num,ListFilterKey key) {
    return *(int*)num > *(int*)key;
}

static int diffInteger(ListElement num1, ListElement num2) {
	assert(num1 && num2);
	return *((int*)num1) - *((int*)num2);
}

static bool testListCreate() {
	ASSERT_TEST(listCreate(NULL,NULL) == NULL);
	ASSERT_TEST(listCreate(NULL,NULL) == NULL);
	ASSERT_TEST(listCreate(copyString,NULL) == NULL);
	ASSERT_TEST(listCreate(NULL,freeString) == NULL);
	List list = listCreate(copyString, freeString);
	ASSERT_TEST(list != NULL);
	listDestroy(list);
	list = listCreate(copyInteger, freeInteger);
	ASSERT_TEST(list != NULL);
	listDestroy(list);
	return true;
}
static bool testListFilter() {
	char* strs[11] = {"Hello", "Darkness", "My", "", "Old", "Friend", "43",
	"Fish1", "Fish2", "Napoleon", "Supernova"};
	int nums[8] = {1, 1, 2, 3, 5, 8, 13, 21};
	List list = listCreate(copyString, freeString);
	for (int i=0;i <11; ++i)
		listInsertFirst(list, strs[i]);
	int key = 5;
	List filtered = listFilter(list, isLongerThanString, &key);
	ASSERT_TEST(listGetSize(filtered) == 4);
	listDestroy(filtered);
	key = 8;
	filtered = listFilter(list, isLongerThanString, &key);
	ASSERT_TEST(listGetSize(filtered) == 1);
	listDestroy(filtered);
	key = 43;
	filtered = listFilter(list, isLongerThanString, &key);
	ASSERT_TEST(listGetSize(filtered) == 0);
	listDestroy(filtered);
	key = 0;
	filtered = listFilter(list, isLongerThanString, &key);
	ASSERT_TEST(listGetSize(filtered) == 10);
	listDestroy(filtered);
	listDestroy(list);
	list = listCreate(copyInteger, freeInteger);
	for (int i=0;i <8; ++i)
		listInsertFirst(list, &(nums[i]));
	key = 4;
	filtered = listFilter(list, isBiggerThanInteger, &key);
	ASSERT_TEST(listGetSize(filtered) == 4);
	listDestroy(filtered);
	listDestroy(list);
	return true;
}
static bool testListCopy() {
	ASSERT_TEST(listCopy(NULL) == NULL);
	List list = listCreate(copyString, freeString);
	List list_copy = listCopy(list);
	ASSERT_TEST(list_copy != NULL);
	listDestroy(list);
	listDestroy(list_copy);
	return true;
}

static bool testListGetSize() {
	char* a[5] = {"aaa","bbb","NI","hello mister fish","I"};
	List list = listCreate(copyString, freeString);
	ASSERT_TEST(listGetSize(list) == 0);
	for (int i=0;i <5; ++i){
		listInsertFirst(list,a[i]);
	}
	ASSERT_TEST(listGetSize(list) == 5);
	listGetFirst(list);
	listRemoveCurrent(list);
	ASSERT_TEST(listGetSize(list) == 4);
	listGetFirst(list);
	listRemoveCurrent(list);
	ASSERT_TEST(listGetSize(list) == 3);
	listDestroy(list);
	return true;
}

static bool testListRemoveCurrent() {
	List list = listCreate(copyInteger, freeInteger);
	ASSERT_TEST(listRemoveCurrent(list) == LIST_INVALID_CURRENT);
	int nums[3] = {1, 2, 3};
	for (int i=0 ;i<3; ++i)
			listInsertFirst(list, &(nums[i]));
	listGetFirst(list);
	ASSERT_TEST(listRemoveCurrent(list) == LIST_SUCCESS);
	ASSERT_TEST(listRemoveCurrent(list) == LIST_INVALID_CURRENT);
	listGetFirst(list);
	ASSERT_TEST(listRemoveCurrent(list) == LIST_SUCCESS);
	listDestroy(list);
	return true;
}

static bool testListSortAndInsert() {
	char* a[5] = {"EEEE5","CC3","B2","FFFFF6","DDD4"};
	int b[11] = {1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89};
	List list = listCreate(copyString, freeString);
	for (int i=0 ;i<5; ++i)
		listInsertLast(list, a[i]);
	listSort(list, diffLengthString);
	ASSERT_TEST(strlen((char*)(listGetFirst(list))) == strlen(a[2]));
	ASSERT_TEST(strlen((char*)(listGetNext(list))) == strlen(a[1]));
	ASSERT_TEST(strlen((char*)(listGetNext(list))) == strlen(a[4]));
	ASSERT_TEST(strlen((char*)(listGetNext(list))) == strlen(a[0]));
	ASSERT_TEST(strlen((char*)(listGetNext(list))) == strlen(a[3]));
	listDestroy(list);
	list = listCreate(copyInteger, freeInteger);
	for (int i=0 ;i<11; ++i)
		listInsertFirst(list, &(b[i]));
	listSort(list, diffInteger);
	ASSERT_TEST(*((int*)listGetFirst(list)) == 1);
	ASSERT_TEST(*((int*)listGetNext(list)) == 1);
	ASSERT_TEST(*((int*)listGetNext(list)) == 2);
	ASSERT_TEST(*((int*)listGetNext(list)) == 3);
	ASSERT_TEST(*((int*)listGetNext(list)) == 5);
	ASSERT_TEST(*((int*)listGetNext(list)) == 8);
	ASSERT_TEST(*((int*)listGetNext(list)) == 13);
	ASSERT_TEST(*((int*)listGetNext(list)) == 21);
	ASSERT_TEST(*((int*)listGetNext(list)) == 34);
	ASSERT_TEST(*((int*)listGetNext(list)) == 55);
	ASSERT_TEST(*((int*)listGetNext(list)) == 89);
	listDestroy(list);
	return true;
}


int main (int argv, char** arc){
	/*
	 * Previous test was accidently completely removed. I already knew that
	 * the list's functionality is okay, so I passed on the trivial functions,
	 * and included them in the implementation of other tests.
	 * Please excuse this relatively-sloppy test.
	*/
	RUN_TEST(testListCreate);
	RUN_TEST(testListCopy);
	RUN_TEST(testListGetSize);
	RUN_TEST(testListRemoveCurrent);
	RUN_TEST(testListFilter);
	RUN_TEST(testListSortAndInsert);
	return 0;
}

