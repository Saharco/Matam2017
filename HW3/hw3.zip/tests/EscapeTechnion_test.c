#include <assert.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include "test_utilities.h"
#include "../EscapeTechnion.h"
#include "../mtm_ex3.h"

#define NOT_INITIALIZED -1

static void fillEscapeTechnionData(EscapeTechnion sys) {
	escapeTechnionAddCompany(sys, "1@com", PHYSICS);
	escapeTechnionAddCompany(sys, "2@com", CHEMISTRY);
	escapeTechnionAddCompany(sys, "3@com", BIOLOGY);
	escapeTechnionAddCompany(sys, "4@com", COMPUTER_SCIENCE);
	escapeTechnionAddCompany(sys, "5@com", CIVIL_ENGINEERING);
	escapeTechnionAddCompany(sys, "6@com", ELECTRICAL_ENGINEERING);
	escapeTechnionAddCompany(sys, "7@com", MEDICINE);
	escapeTechnionAddCompany(sys, "8@com", MECHANICAL_ENGINEERING);
	escapeTechnionAddCompany(sys, "9@com", PHYSICS);
	escapeTechnionAddRoom(sys, "1@com", 1, 100, 1, "08-20", 3);//physics
	escapeTechnionAddRoom(sys, "1@com", 10, 80, 3, "08-20", 6);//physics
	escapeTechnionAddRoom(sys, "1@com", 11, 92, 3, "08-20", 6);//physics
	escapeTechnionAddRoom(sys, "2@com", 1, 40, 2, "08-20", 10);//chemistry
	escapeTechnionAddRoom(sys, "3@com", 1, 20, 2, "08-20", 5);//bio
	escapeTechnionAddRoom(sys, "4@com", 1, 12, 2, "08-20", 5);//CS
	escapeTechnionAddRoom(sys, "5@com", 1, 4, 2, "08-20", 5);//civil
	escapeTechnionAddRoom(sys, "6@com", 1, 40, 4, "08-20", 5);//electrical
	escapeTechnionAddRoom(sys, "7@com", 1, 24, 1, "08-20", 5);//medicine
	escapeTechnionAddRoom(sys, "8@com", 1, 4, 6, "08-20", 5);//mechanical
	escapeTechnionAddRoom(sys, "9@com", 3, 4, 15, "08-20", 5);//physics
	escapeTechnionAddEscaper(sys, "1@esc", PHYSICS, 1);
	escapeTechnionAddEscaper(sys, "2@esc", MATHEMATICS, 7);
	escapeTechnionAddEscaper(sys, "3@esc", MATHEMATICS, 4);
	escapeTechnionEscaperOrder(sys, "1@esc", PHYSICS, 1, "00-08", 1); //75 V
	escapeTechnionEscaperOrder(sys, "1@esc", PHYSICS, 10, "00-09", 4); //240 V
	escapeTechnionEscaperOrder(sys, "1@esc", CHEMISTRY, 1, "00-10", 3); //120 V
	escapeTechnionEscaperOrder(sys, "1@esc", BIOLOGY, 1, "00-11", 1); //20 V
	escapeTechnionEscaperOrder(sys, "1@esc", COMPUTER_SCIENCE, 1, "00-12", 4); //48 V
	escapeTechnionEscaperOrder(sys, "1@esc", PHYSICS, 3, "00-13", 15); //45 V
	escapeTechnionEscaperOrder(sys, "1@esc", PHYSICS, 10, "00-14", 4); //240 V
	escapeTechnionEscaperOrder(sys, "1@esc", PHYSICS, 11, "00-15", 8); //552 V
	escapeTechnionEscaperOrder(sys, "1@esc", CHEMISTRY, 1, "00-19", 4); //160 V
	escapeTechnionEscaperOrder(sys, "2@esc", BIOLOGY, 1, "00-09", 3); //60 V
	escapeTechnionEscaperOrder(sys, "2@esc", COMPUTER_SCIENCE, 1, "00-10", 4); //48 V
	escapeTechnionEscaperOrder(sys, "2@esc", MECHANICAL_ENGINEERING, 1,
	"00-11", 652); //2608 V
	escapeTechnionEscaperOrder(sys, "2@esc", PHYSICS, 3, "00-14", 15); //60 V
	escapeTechnionEscaperOrder(sys, "2@esc", MEDICINE, 1, "00-19", 1); //24 V
	escapeTechnionEscaperOrder(sys, "3@esc", ELECTRICAL_ENGINEERING, 1,
	"00-08", 3); //120 V
	escapeTechnionEscaperOrder(sys, "3@esc", ELECTRICAL_ENGINEERING, 1,
	"00-19", 4); //160 V
	escapeTechnionEscaperOrder(sys, "1@esc", CIVIL_ENGINEERING, 1, "01-17",
	653); //2612
	escapeTechnionEscaperOrder(sys, "1@esc", PHYSICS, 1, "01-12", 12); //900
	escapeTechnionEscaperOrder(sys, "2@esc", PHYSICS, 1, "01-18", 5); //500
	escapeTechnionEscaperOrder(sys, "3@esc", BIOLOGY, 1, "01-12", 3); //60
}

static bool testEscapeTechnionCreate() {
	EscapeTechnion sys = escapeTechnionCreate();
	ASSERT_TEST(sys != NULL);
	escapeTechnionDestroy(sys);
	return true;
}

static bool testEscapeTechnionModifyOutput() {
	return true;
}


static bool testEscapeTechnionDestroy() {
	return true;
}

static bool testEscapeTechnionCopy() {
	return true;
}


static bool testEscapeTechnionAddCompany() {
	EscapeTechnion sys = escapeTechnionCreate();
	ASSERT_TEST(escapeTechnionAddCompany(sys, "no", BIOLOGY) ==
	ESCAPE_TECHNION_INVALID_PARAMETER);
	ASSERT_TEST(escapeTechnionAddCompany(sys, "@no@", BIOLOGY) ==
	ESCAPE_TECHNION_INVALID_PARAMETER);
	ASSERT_TEST(escapeTechnionAddCompany(sys, "yes@", UNKNOWN) ==
	ESCAPE_TECHNION_INVALID_PARAMETER);
	ASSERT_TEST(escapeTechnionAddCompany(sys, "yes@", -1) ==
	ESCAPE_TECHNION_INVALID_PARAMETER);
	ASSERT_TEST(escapeTechnionAddCompany(NULL, "yes@", BIOLOGY) ==
	ESCAPE_TECHNION_NULL_PARAMETER);
	ASSERT_TEST(escapeTechnionAddCompany(sys, NULL, BIOLOGY) ==
	ESCAPE_TECHNION_NULL_PARAMETER);
	ASSERT_TEST(escapeTechnionAddCompany(sys, "yes@", BIOLOGY) ==
	ESCAPE_TECHNION_SUCCESS);
	ASSERT_TEST(escapeTechnionAddCompany(sys, "yes@", PHYSICS) ==
	ESCAPE_TECHNION_EMAIL_ALREADY_EXISTS);
	//
	escapeTechnionDestroy(sys);
	return true;
}


static bool testEscapeTechnionRemoveCompany() {
	EscapeTechnion sys = escapeTechnionCreate();
	ASSERT_TEST(escapeTechnionRemoveCompany(sys, "to@remove") ==
	ESCAPE_TECHNION_COMPANY_EMAIL_DOES_NOT_EXIST);
	escapeTechnionAddCompany(sys, "to@remove", CHEMISTRY);
	ASSERT_TEST(escapeTechnionRemoveCompany(sys, "toremove") ==
	ESCAPE_TECHNION_INVALID_PARAMETER);
	ASSERT_TEST(escapeTechnionRemoveCompany(sys, NULL) ==
	ESCAPE_TECHNION_NULL_PARAMETER);
	escapeTechnionAddEscaper(sys, "escaper@", PHYSICS, 6);
	ASSERT_TEST(escapeTechnionRemoveCompany(sys, "escaper@") ==
	ESCAPE_TECHNION_COMPANY_EMAIL_DOES_NOT_EXIST);
	ASSERT_TEST(escapeTechnionRemoveCompany(sys, "to@remove") ==
	ESCAPE_TECHNION_SUCCESS);
	escapeTechnionAddCompany(sys, "best@rooms", COMPUTER_SCIENCE);
	escapeTechnionAddRoom(sys, "best@rooms", 43, 40, 3, "06-20", 8);
	escapeTechnionAddEscaper(sys, "best@escaper", PHYSICS, 3);
	escapeTechnionEscaperOrder(sys, "best@escaper", COMPUTER_SCIENCE,
	43, "00-08", 3);
	ASSERT_TEST(escapeTechnionRemoveCompany(sys, "best@rooms") ==
	ESCAPE_TECHNION_RESERVATION_EXISTS);
	escapeTechnionDestroy(sys);
	return true;
}


static bool testEscapeTechnionAddRoom() {
	EscapeTechnion sys = escapeTechnionCreate();
	ASSERT_TEST(escapeTechnionAddRoom(sys, "no@", 1, 40, 2, "10-22", 3) ==
	ESCAPE_TECHNION_COMPANY_EMAIL_DOES_NOT_EXIST);
	escapeTechnionAddCompany(sys, "yes@", PHYSICS);
	ASSERT_TEST(escapeTechnionAddRoom(sys, "yes@", 1, 39, 2, "10-22", 3) ==
	ESCAPE_TECHNION_INVALID_PARAMETER);
	ASSERT_TEST(escapeTechnionAddRoom(sys, "yes", 1, 40, 2, "10-22", 3) ==
	ESCAPE_TECHNION_INVALID_PARAMETER);
	ASSERT_TEST(escapeTechnionAddRoom(sys, "yes@", 1, 40, 0, "10-22", 3) ==
	ESCAPE_TECHNION_INVALID_PARAMETER);
	ASSERT_TEST(escapeTechnionAddRoom(sys, "yes@", 1, 40, 2, "1234", 3) ==
	ESCAPE_TECHNION_INVALID_PARAMETER);
	ASSERT_TEST(escapeTechnionAddRoom(sys, "yes@", 1, 40, 2, "22-22", 3) ==
	ESCAPE_TECHNION_INVALID_PARAMETER);
	ASSERT_TEST(escapeTechnionAddRoom(sys, NULL, 0, 0, 0, "10-22", 1) ==
	ESCAPE_TECHNION_NULL_PARAMETER);
	ASSERT_TEST(escapeTechnionAddRoom(sys, "yes@", 1, 40, 2, "10-22", 3) ==
	ESCAPE_TECHNION_SUCCESS);
	ASSERT_TEST(escapeTechnionAddRoom(sys, "yes@", 1, 80, 3, "08-22", 5) ==
	ESCAPE_TECHNION_ID_ALREADY_EXIST);
	escapeTechnionAddCompany(sys, "hello@mata.mm", PHYSICS);
	ASSERT_TEST(escapeTechnionAddRoom(sys, "yes@", 1, 80, 3, "08-22", 5) ==
	ESCAPE_TECHNION_ID_ALREADY_EXIST);
	escapeTechnionAddCompany(sys, "mata.mm@hello", COMPUTER_SCIENCE);
	ASSERT_TEST(escapeTechnionAddRoom(sys, "mata.mm@hello", 1, 80, 3, "08-22",
	5) == ESCAPE_TECHNION_SUCCESS);
	escapeTechnionDestroy(sys);
	return true;
}


static bool testEscapeTechnionRemoveRoom() {
	EscapeTechnion sys = escapeTechnionCreate();
	ASSERT_TEST(escapeTechnionRemoveRoom(sys, BIOLOGY, 1) ==
	ESCAPE_TECHNION_ID_DOES_NOT_EXIST);
	escapeTechnionAddCompany(sys, "1@com", BIOLOGY);
	escapeTechnionAddCompany(sys, "2@com", PHYSICS);
	escapeTechnionAddRoom(sys, "1@com", 43, 40, 2, "08-20", 3);
	escapeTechnionAddRoom(sys, "2@com", 44, 40, 2, "08-20", 3);
	ASSERT_TEST(escapeTechnionRemoveRoom(sys, BIOLOGY, 44) ==
	ESCAPE_TECHNION_ID_DOES_NOT_EXIST);
	ASSERT_TEST(escapeTechnionRemoveRoom(sys, BIOLOGY, -1) ==
	ESCAPE_TECHNION_INVALID_PARAMETER);
	ASSERT_TEST(escapeTechnionRemoveRoom(sys, PHYSICS, 44) ==
	ESCAPE_TECHNION_SUCCESS);
	escapeTechnionAddEscaper(sys, "yes@", PHYSICS, 3);
	escapeTechnionEscaperOrder(sys, "yes@", BIOLOGY, 43, "01-09", 3);
	ASSERT_TEST(escapeTechnionRemoveRoom(sys, BIOLOGY, 43) ==
	ESCAPE_TECHNION_RESERVATION_EXISTS);
	escapeTechnionDestroy(sys);
	return true;
}

static bool testEscapeTechnionAddEscaper() {
	EscapeTechnion sys = escapeTechnionCreate();
	ASSERT_TEST(escapeTechnionAddEscaper(sys, "no", BIOLOGY, 1) ==
	ESCAPE_TECHNION_INVALID_PARAMETER);
	ASSERT_TEST(escapeTechnionAddEscaper(sys, "@no@", BIOLOGY, 1) ==
	ESCAPE_TECHNION_INVALID_PARAMETER);
	ASSERT_TEST(escapeTechnionAddEscaper(sys, "yes@", UNKNOWN, 1) ==
	ESCAPE_TECHNION_INVALID_PARAMETER);
	ASSERT_TEST(escapeTechnionAddEscaper(sys, "yes@", -1, 1) ==
	ESCAPE_TECHNION_INVALID_PARAMETER);
	ASSERT_TEST(escapeTechnionAddEscaper(NULL, "yes@", BIOLOGY, 1) ==
	ESCAPE_TECHNION_NULL_PARAMETER);
	ASSERT_TEST(escapeTechnionAddEscaper(sys, NULL, BIOLOGY, 1) ==
	ESCAPE_TECHNION_NULL_PARAMETER);
	ASSERT_TEST(escapeTechnionAddEscaper(sys, "yes@", BIOLOGY, 1) ==
	ESCAPE_TECHNION_SUCCESS);
	ASSERT_TEST(escapeTechnionAddEscaper(sys, "yes@", PHYSICS, 1) ==
	ESCAPE_TECHNION_EMAIL_ALREADY_EXISTS);
	escapeTechnionAddCompany(sys, "yes2@", CHEMISTRY);
	ASSERT_TEST(escapeTechnionAddEscaper(sys, "yes2@", PHYSICS, 1) ==
	ESCAPE_TECHNION_EMAIL_ALREADY_EXISTS);
	escapeTechnionDestroy(sys);
	return true;
}


static bool testEscapeTechnionRemoveEscaper() {
	EscapeTechnion sys = escapeTechnionCreate();
	ASSERT_TEST(escapeTechnionRemoveEscaper(sys, "yes@") ==
	ESCAPE_TECHNION_CLIENT_EMAIL_DOES_NOT_EXIST);
	escapeTechnionAddEscaper(sys, "yes@", PHYSICS, 1);
	ASSERT_TEST(escapeTechnionRemoveEscaper(sys, "yes") ==
	ESCAPE_TECHNION_INVALID_PARAMETER);
	ASSERT_TEST(escapeTechnionRemoveEscaper(sys, NULL) ==
	ESCAPE_TECHNION_NULL_PARAMETER);
	ASSERT_TEST(escapeTechnionRemoveEscaper(sys, "yes@") ==
	ESCAPE_TECHNION_SUCCESS);
	escapeTechnionDestroy(sys);
	return true;
}


static bool testEscapeTechnionEscaperOrder() {
	EscapeTechnion sys = escapeTechnionCreate();
	ASSERT_TEST(escapeTechnionEscaperOrder(sys, "yes@", PHYSICS, 55, "1-9",
	3) == ESCAPE_TECHNION_CLIENT_EMAIL_DOES_NOT_EXIST);
	ASSERT_TEST(escapeTechnionEscaperOrder(sys, "yes", PHYSICS, 55, "1-9",
	3) == ESCAPE_TECHNION_INVALID_PARAMETER);
	escapeTechnionAddEscaper(sys, "yes@", COMPUTER_SCIENCE, 5);
	ASSERT_TEST(escapeTechnionEscaperOrder(sys, "yes@", PHYSICS, 55, "1-9",
	3) == ESCAPE_TECHNION_ID_DOES_NOT_EXIST);
	escapeTechnionAddCompany(sys, "best@com", COMPUTER_SCIENCE);
	escapeTechnionAddRoom(sys, "best@com", 55, 40, 2, "06-20", 3);
	ASSERT_TEST(escapeTechnionEscaperOrder(sys, "yes@", PHYSICS, 55, "1-9",
	3) == ESCAPE_TECHNION_ID_DOES_NOT_EXIST);
	escapeTechnionAddCompany(sys, "best2@com", PHYSICS);
	escapeTechnionAddRoom(sys, "best2@com", 56, 40, 2, "06-20", 3);
	ASSERT_TEST(escapeTechnionEscaperOrder(sys, "yes@", PHYSICS, 55, "1-9",
	3) == ESCAPE_TECHNION_ID_DOES_NOT_EXIST);
	//RESERVATION PROBLEM
	ASSERT_TEST(escapeTechnionEscaperOrder(sys, "yes@", PHYSICS, 56, "01-09",
	3) == ESCAPE_TECHNION_SUCCESS);
	escapeTechnionAddRoom(sys, "best@com", 43, 80, 3, "07-19", 5);
	ASSERT_TEST(escapeTechnionEscaperOrder(sys, "yes@", COMPUTER_SCIENCE, 43,
	"01-09", 3) == ESCAPE_TECHNION_CLIENT_IN_ROOM);
	escapeTechnionDestroy(sys);
	return true;
}

static bool testEscapeTechnionReport() {
	EscapeTechnion sys = escapeTechnionCreate();
	fillEscapeTechnionData(sys); //Fills the system with a large sample of data
	ASSERT_TEST(escapeTechnionReportDay(sys) == ESCAPE_TECHNION_SUCCESS);
	printf("\n\n");
	ASSERT_TEST(escapeTechnionReportBest(sys) == ESCAPE_TECHNION_SUCCESS);
	printf("\n\n");
	ASSERT_TEST(escapeTechnionReportDay(sys) == ESCAPE_TECHNION_SUCCESS);
	printf("\n\n");
	ASSERT_TEST(escapeTechnionReportBest(sys) == ESCAPE_TECHNION_SUCCESS);
	escapeTechnionDestroy(sys);
	return true;
}

static bool testEscapeTechnionEscaperRecommend() {
	EscapeTechnion sys = escapeTechnionCreate();
	ASSERT_TEST(escapeTechnionEscaperRecommend(sys, "esc@1", 4) ==
	ESCAPE_TECHNION_CLIENT_EMAIL_DOES_NOT_EXIST);
	escapeTechnionAddEscaper(sys, "esc@1", BIOLOGY, 9);
	ASSERT_TEST(escapeTechnionEscaperRecommend(sys, "esc1", 4) ==
	ESCAPE_TECHNION_INVALID_PARAMETER);
	ASSERT_TEST(escapeTechnionEscaperRecommend(sys, "esc@1", 4) ==
	ESCAPE_TECHNION_NO_ROOMS_AVAILABLE);
	escapeTechnionAddCompany(sys, "10@com", MEDICINE);
	escapeTechnionAddRoom(sys, "10@com", 34, 60, 5, "11-20", 9);
	escapeTechnionAddRoom(sys, "10@com", 43, 100, 10, "12-14", 8);
	escapeTechnionAddEscaper(sys, "esc@2", PHYSICS, 1);
	escapeTechnionEscaperOrder(sys, "esc@2", MEDICINE, 43, "0-12", 3);
	escapeTechnionEscaperOrder(sys, "esc@2", MEDICINE, 43, "0-13", 3);
	escapeTechnionEscaperOrder(sys, "esc@2", MEDICINE, 43, "1-13", 3);
	ASSERT_TEST(escapeTechnionEscaperRecommend(sys, "esc@1", 10) ==
	ESCAPE_TECHNION_SUCCESS);
	escapeTechnionReportDay(sys);
	escapeTechnionReportDay(sys);
	escapeTechnionDestroy(sys);
	return true;
}

int main(int argv, char** arc) {
	RUN_TEST(testEscapeTechnionCreate);
	RUN_TEST(testEscapeTechnionModifyOutput);
	RUN_TEST(testEscapeTechnionDestroy);
	RUN_TEST(testEscapeTechnionCopy);
	RUN_TEST(testEscapeTechnionAddCompany);
	RUN_TEST(testEscapeTechnionRemoveCompany);
	RUN_TEST(testEscapeTechnionAddRoom);
	RUN_TEST(testEscapeTechnionRemoveRoom);
	RUN_TEST(testEscapeTechnionAddEscaper);
	RUN_TEST(testEscapeTechnionRemoveEscaper);
	RUN_TEST(testEscapeTechnionEscaperOrder);
	RUN_TEST(testEscapeTechnionReport);
	RUN_TEST(testEscapeTechnionEscaperRecommend);
	return 0;
}
