#include <assert.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include "test_utilities.h"
#include "../Room.h"
#include "../mtm_ex3.h"

#define NOT_INITIALIZED -1

static bool testRoomCreate() {
	/*ORDER OF CREATE FUNCTION:
	* id, price, num_ppl, difficulty, time(string)*/
	RoomResult result;
	ASSERT_TEST(roomCreate(&result, -1, 4, 1, 1, "00-01") == NULL);
	ASSERT_TEST(result = ROOM_INVALID_PARAMETER);
	ASSERT_TEST(roomCreate(&result, -1, 4, 1, 1, NULL) == NULL);
	ASSERT_TEST(result = ROOM_NULL_PARAMETER);
	ASSERT_TEST(roomCreate(NULL, 1, -1, 1, 1, "00-01") == NULL);
	ASSERT_TEST(roomCreate(NULL, 1, 3, 1, 1, "00-01") == NULL);
	ASSERT_TEST(roomCreate(NULL, 1, 4, 0, 1, "00-01") == NULL);
	ASSERT_TEST(roomCreate(NULL, 1, 4, 1, 0, "00-01") == NULL);
	ASSERT_TEST(roomCreate(NULL, 1, 4, 1, 11, "00-01") == NULL);
	ASSERT_TEST(roomCreate(NULL, 1, 4, 1, 1, "00-00") == NULL);
	ASSERT_TEST(roomCreate(NULL, 1, 4, 1, 1, "agfg") == NULL);
	ASSERT_TEST(roomCreate(NULL, 1, 4, 1, 1, "agfgg") == NULL);
	ASSERT_TEST(roomCreate(NULL, 1, 4, 1, 1, "") == NULL);
	ASSERT_TEST(roomCreate(NULL, 1, 4, 1, 1, "02314") == NULL);
	ASSERT_TEST(roomCreate(NULL, 1, 4, 1, 1, "02-1x") == NULL);
	ASSERT_TEST(roomCreate(NULL, 1, 4, 1, 1, "00-24") == NULL);
	ASSERT_TEST(roomCreate(NULL, 1, 4, 1, 1, "25-40") == NULL);
	//The room successfully checks for illegal parameters!
	Room room = roomCreate(&result, 1, 4, 1, 1, "08-20");
	ASSERT_TEST(result == ROOM_SUCCESS);
	ASSERT_TEST(room != NULL);
	roomDestroy(room);
	room = roomCreate(NULL, 23, 48, 3, 10, "00-23");
	ASSERT_TEST(room != NULL);
	roomDestroy(room);
	room = roomCreate(NULL, 439879, 88, 50, 7, "07-19");
	ASSERT_TEST(room != NULL);
	roomDestroy(room);
	return true;
}

static bool testRoomDestroy() {
	Room room = roomCreate(NULL, 1, 40, 1, 5, "08-20");
	ASSERT_TEST(roomDestroy(room) == ROOM_SUCCESS);
	room = roomCreate(NULL, -3, 40, 1, 5, "08-20");
	ASSERT_TEST(roomDestroy(room) == ROOM_NULL_PARAMETER);
	return true;
}

static bool testRoomCopy() {
	int id=0, price=0, open=0, close=0, difficulty=0, money1=0, money2=0;
	Room room = roomCreate(NULL, 1, 40, 1, 5, "08-20");
	//CREATE: email, id, faculty, price, open, close, ppl, date, discount
	Reservation reservation = reservationCreate(NULL, "res@", 1, PHYSICS, 40,
	8, 20, 1, "00-10", false);
	roomNewReservation(room, reservation);
	Room room_copy = roomCopy(room);
	ASSERT_TEST(room_copy);
	roomGetId(room_copy, &id);
	roomGetPrice(room_copy, &price);
	roomGetOpenTime(room_copy, &open);
	roomGetCloseTime(room_copy, &close);
	roomGetDifficulty(room_copy, &difficulty);
	roomEarns(room_copy, &money2);
	ASSERT_TEST(id == 1);
	ASSERT_TEST(price == 40);
	ASSERT_TEST(difficulty == 5);
	ASSERT_TEST(money2 == 0);
	ASSERT_TEST(roomHasReservations(room_copy));
	roomNextDay(room);
	ASSERT_TEST(roomHasReservations(room_copy));
	roomEarns(room, &money1);
	ASSERT_TEST(money1 != money2);
	roomDestroy(room);
	roomDestroy(room_copy);
	reservationDestroy(reservation);
 	return true;
}

static bool testRoomGetId() {
	int id=0;
	Room room = roomCreate(NULL, 1, 4, 1, 1, "08-20");
	roomGetId(room, &id);
	ASSERT_TEST(id == 1);
	roomDestroy(room);
	room = roomCreate(NULL, 53, 4, 1, 1, "08-20");
	roomGetId(room, &id);
	ASSERT_TEST(id == 53);
	roomDestroy(room);
	id = NOT_INITIALIZED;
	room = roomCreate(NULL, -9, 4, 1, 1, "08-20");
	roomGetId(room, &id);
	ASSERT_TEST(id == NOT_INITIALIZED);
	return true;
}

static bool testRoomGetPrice() {
	int price=0;
	Room room = roomCreate(NULL, 1, 4, 1, 1, "08-20");
	roomGetPrice(room, &price);
	ASSERT_TEST(price == 4);
	roomDestroy(room);
	room = roomCreate(NULL, 1, 40, 1, 1, "08-20");
	roomGetPrice(room, &price);
	ASSERT_TEST(price == 40);
	roomDestroy(room);
	price = NOT_INITIALIZED;
	room = roomCreate(NULL, 1, -1, 1, 1, "08-20");
	roomGetPrice(room, &price);
	ASSERT_TEST(price == NOT_INITIALIZED);
	room = roomCreate(NULL, 1, 3, 1, 1, "08-20");
	roomGetPrice(room, &price);
	ASSERT_TEST(price == NOT_INITIALIZED);
	return true;
}

static bool testRoomGetOpenTime() {
	int open=0;
	Room room = roomCreate(NULL, 1, 4, 1, 1, "08-20");
	roomGetOpenTime(room, &open);
	ASSERT_TEST(open == 8);
	roomDestroy(room);
	room = roomCreate(NULL, 1, 40, 1, 1, "00-20");
	roomGetOpenTime(room, &open);
	ASSERT_TEST(open == 0);
	roomDestroy(room);
	open = NOT_INITIALIZED;
	room = roomCreate(NULL, 1, -1, 1, 1, "21-20");
	roomGetOpenTime(room, &open);
	ASSERT_TEST(open == NOT_INITIALIZED);
	room = roomCreate(NULL, 1, 3, 1, 1, "10-25");
	roomGetOpenTime(room, &open);
	ASSERT_TEST(open == NOT_INITIALIZED);
	return true;
}

static bool testRoomGetCloseTime() {
	int close=0;
	Room room = roomCreate(NULL, 1, 4, 1, 1, "08-20");
	roomGetCloseTime(room, &close);
	ASSERT_TEST(close == 20);
	roomDestroy(room);
	room = roomCreate(NULL, 1, 40, 1, 1, "00-01");
	roomGetCloseTime(room, &close);
	ASSERT_TEST(close == 1);
	roomDestroy(room);
	close = NOT_INITIALIZED;
	room = roomCreate(NULL, 1, -1, 1, 1, "11-25");
	roomGetCloseTime(room, &close);
	ASSERT_TEST(close == NOT_INITIALIZED);
	room = roomCreate(NULL, 1, 3, 1, 1, "23-20");
	roomGetCloseTime(room, &close);
	ASSERT_TEST(close == NOT_INITIALIZED);
	return true;
}

static bool testRoomGetDifficulty() {
	int difficulty=0;
	Room room = roomCreate(NULL, 1, 4, 1, 1, "08-20");
	roomGetDifficulty(room, &difficulty);
	ASSERT_TEST(difficulty == 1);
	roomDestroy(room);
	room = roomCreate(NULL, 1, 4, 1, 9, "08-20");
	roomGetDifficulty(room, &difficulty);
	ASSERT_TEST(difficulty == 9);
	roomDestroy(room);
	room = roomCreate(NULL, 1, 4, 1, 10, "08-20");
	roomGetDifficulty(room, &difficulty);
	ASSERT_TEST(difficulty == 10);
	roomDestroy(room);
	difficulty = NOT_INITIALIZED;
	room = roomCreate(NULL, 1, 4, 1, 11, "08-20");
	roomGetDifficulty(room, &difficulty);
	ASSERT_TEST(difficulty == NOT_INITIALIZED);
	room = roomCreate(NULL, 1, 4, 1, -2, "08-20");
	roomGetDifficulty(room, &difficulty);
	ASSERT_TEST(difficulty == NOT_INITIALIZED);
	return true;
}

static bool testRoomEarns() {
	Room room = roomCreate(NULL, 1, 40, 1, 1, "08-20");
	int id=0, price=0, open=0, close=0;
	roomGetId(room, &id);
	roomGetPrice(room, &price);
	roomGetOpenTime(room, &open);
	roomGetCloseTime(room, &close);
	Reservation reservation1 = reservationCreate(NULL, "res@1", id, PHYSICS,
	price, open, close, 1, "00-08", false);
	Reservation reservation2 = reservationCreate(NULL, "res@2", id, PHYSICS,
	price, open, close, 2, "00-09", false);
	Reservation reservation3 = reservationCreate(NULL, "res@3", id, PHYSICS,
	price, open, close, 3, "00-10", false);
	Reservation reservation4 = reservationCreate(NULL, "res@4", id, PHYSICS,
	price, open, close, 1, "01-08", true);
	Reservation reservation5 = reservationCreate(NULL, "res@5", id, PHYSICS,
	price, open, close, 2, "01-09", true);
	Reservation reservation6 = reservationCreate(NULL, "res@6", id, PHYSICS,
	price, open, close, 3, "01-10", true);
	//We add the new reservations in random order
	roomNewReservation(room, reservation1);	//This reservation costs 40
	roomNewReservation(room, reservation6);	//This reservation costs 80
	roomNewReservation(room, reservation2);	//This reservation costs 120
	//This discounted reservation costs 30
	roomNewReservation(room, reservation5);
	//This discounted reservation costs 60
	roomNewReservation(room, reservation3);
	//This discounted reservation costs 90
	roomNewReservation(room, reservation4);
	int money = NOT_INITIALIZED;
	roomEarns(room, &money);
	ASSERT_TEST(money == 0);
	roomNextDay(room);
	roomEarns(room, &money);
	ASSERT_TEST(money == 240);
	roomNextDay(room);
	roomEarns(room, &money);
	ASSERT_TEST(money == 420);
	roomDestroy(room);
	reservationDestroy(reservation1);
	reservationDestroy(reservation2);
	reservationDestroy(reservation3);
	reservationDestroy(reservation4);
	reservationDestroy(reservation5);
	reservationDestroy(reservation6);
	return true;
}

static bool testRoomHasReservations() {
	Room room = roomCreate(NULL, 1, 40, 1, 1, "08-20");
	int id=0, price=0, open=0, close=0;
	roomGetId(room, &id);
	roomGetPrice(room, &price);
	roomGetOpenTime(room, &open);
	roomGetCloseTime(room, &close);
	ASSERT_TEST(!roomHasReservations(room));
	//CREATE: email, id, faculty, price, open, close, ppl, date, discount
	Reservation reservation = reservationCreate(NULL, "barvaz@gad.ol", id,
	PHYSICS, price, open, close, 3, "03-10", false);
	roomNewReservation(room, reservation);
	ASSERT_TEST(roomHasReservations(room));
	roomDestroy(room);
	reservationDestroy(reservation);
	return true;
}

static bool testRoomNewReservation() {
	Room room = roomCreate(NULL, 1, 40, 1, 1, "08-20");
	int id=0, price=0, open=0, close=0;
	roomGetId(room, &id);
	roomGetPrice(room, &price);
	roomGetOpenTime(room, &open);
	roomGetCloseTime(room, &close);
	//CREATE: email, id, faculty, price, open, close, ppl, date, discount
	Reservation reservation1 = reservationCreate(NULL, "barvaz@gad.ol", id,
	PHYSICS, price, open, close, 3, "03-10", false);
	ASSERT_TEST(roomNewReservation(room, reservation1)==ROOM_SUCCESS);
	Reservation reservation2 = reservationCreate(NULL, "barvaz@an.ak", id,
	COMPUTER_SCIENCE, price, open, close, 6, "03-10", false);
	ASSERT_TEST(reservation2);
	ASSERT_TEST(roomNewReservation(room, reservation2)==ROOM_ALREADY_RESERVED);
	roomDestroy(room);
	reservationDestroy(reservation1);
	reservationDestroy(reservation2);
	return true;
}

static bool testRoomNextDay() {
	Room room = roomCreate(NULL, 1, 40, 1, 1, "08-20");
	int id=0, price=0, open=0, close=0;
	roomGetId(room, &id);
	roomGetPrice(room, &price);
	roomGetOpenTime(room, &open);
	roomGetCloseTime(room, &close);
	//CREATE: email, id, faculty, price, open, close, ppl, date, discount
	Reservation reservation1 = reservationCreate(NULL, "res@1", id, PHYSICS,
	price, open, close, 1, "00-08", false);
	Reservation reservation2 = reservationCreate(NULL, "res@2", id, PHYSICS,
	price, open, close, 2, "00-09", false);
	Reservation reservation3 = reservationCreate(NULL, "res@3", id, PHYSICS,
	price, open, close, 3, "00-10", false);
	Reservation reservation4 = reservationCreate(NULL, "res@4", id, PHYSICS,
	price, open, close, 1, "01-08", true);
	Reservation reservation5 = reservationCreate(NULL, "res@5", id, PHYSICS,
	price, open, close, 2, "01-09", true);
	Reservation reservation6 = reservationCreate(NULL, "res@6", id, PHYSICS,
	price, open, close, 3, "01-10", true);
	//We add the new reservations in random order
	roomNewReservation(room, reservation1);
	roomNewReservation(room, reservation6);
	roomNewReservation(room, reservation2);
	roomNewReservation(room, reservation5);
	roomNewReservation(room, reservation3);
	roomNewReservation(room, reservation4);
	ASSERT_TEST(roomNextDay(room) == ROOM_SUCCESS);
	ASSERT_TEST(roomNextDay(room) == ROOM_SUCCESS);
	ASSERT_TEST(!roomHasReservations(room));
	roomDestroy(room);
	reservationDestroy(reservation1);
	reservationDestroy(reservation2);
	reservationDestroy(reservation3);
	reservationDestroy(reservation4);
	reservationDestroy(reservation5);
	reservationDestroy(reservation6);
	return true;
}

static bool testRoomTodaysReservations() {
	Room room = roomCreate(NULL, 1, 40, 1, 1, "08-20");
	int id=0, price=0, open=0, close=0;
	roomGetId(room, &id);
	roomGetPrice(room, &price);
	roomGetOpenTime(room, &open);
	roomGetCloseTime(room, &close);
	//CREATE: email, id, faculty, price, open, close, ppl, date, discount
	Reservation reservation1 = reservationCreate(NULL, "barvaz@gad.ol", id,
	PHYSICS, price, open, close, 3, "0-10", false);
	Reservation reservation2 = reservationCreate(NULL, "barvaz@an.ak", id,
	COMPUTER_SCIENCE, price, open, close, 6, "0-11", false);
	Reservation reservation3 = reservationCreate(NULL, "barvaz@an.ak", id,
	COMPUTER_SCIENCE, price, open, close, 5, "1-10", false);
	roomNewReservation(room, reservation1);
	roomNewReservation(room, reservation2);
	roomNewReservation(room, reservation3);
	ASSERT_TEST(roomTodaysReservations(room) == 2);
	roomNextDay(room);
	ASSERT_TEST(roomTodaysReservations(room) == 1);
	reservationDestroy(reservation1);
	reservationDestroy(reservation2);
	reservationDestroy(reservation3);
	roomDestroy(room);
	return true;
}

static bool testRoomGetReservationInTime() {
	Room room = roomCreate(NULL, 1, 40, 3, 4, "08-20");
	int id=0, price=0, open=0, close=0;
	roomGetId(room, &id);
	roomGetPrice(room, &price);
	roomGetOpenTime(room, &open);
	roomGetCloseTime(room, &close);
	Reservation reservation1 = reservationCreate(NULL, "res@1", id, PHYSICS,
	price, open, close, 1, "00-8", false);
	Reservation reservation2 = reservationCreate(NULL, "res@2", id, PHYSICS,
	price, open, close, 3, "00-10", false);
	Reservation reservation3 = reservationCreate(NULL, "res@3", id, PHYSICS,
	price, open, close, 3, "01-10", true);
	roomNewReservation(room, reservation1);
	roomNewReservation(room, reservation2);
	roomNewReservation(room, reservation3);
	ASSERT_TEST(roomGetReservationInTime(room, 9) == NULL);
	ASSERT_TEST(roomGetReservationInTime(room, 8) != NULL);
	ASSERT_TEST(roomGetReservationInTime(room, 11) == NULL);
	ASSERT_TEST(roomGetReservationInTime(room, 10) != NULL);
	roomNextDay(room);
	ASSERT_TEST(roomGetReservationInTime(room, 34) == NULL);
	ASSERT_TEST(roomGetReservationInTime(room, 10) != NULL);
	roomDestroy(room);
	reservationDestroy(reservation1);
	reservationDestroy(reservation2);
	reservationDestroy(reservation3);
	return true;


}
static bool testRoomCalculatedScore() {
	Room room1 = roomCreate(NULL, 1, 40, 5, 6, "08-20");
	int id1=0, price1=0, open1=0, close1=0;
	roomGetId(room1, &id1);
	roomGetPrice(room1, &price1);
	roomGetOpenTime(room1, &open1);
	roomGetCloseTime(room1, &close1);
	ASSERT_TEST(roomCalculatedScore(room1, 2, 4) == 17);
	ASSERT_TEST(roomCalculatedScore(room1, 6, 5) == 0);
	Room room2 = roomCreate(NULL, 1, 35, 5, 14, "08-20");
	int id2=0, price2=0, open2=0, close2=0;
	roomGetId(room2, &id2);
	roomGetPrice(room2, &price2);
	roomGetOpenTime(room2, &open2);
	roomGetCloseTime(room2, &close2);
	ASSERT_TEST(roomCalculatedScore(room2, 7, 2) == -1);
	roomDestroy(room1);
	roomDestroy(room2);
	return true;
}

int main(int argv, char** arc) {
	RUN_TEST(testRoomCreate);
	RUN_TEST(testRoomGetId);
	RUN_TEST(testRoomGetPrice);
	RUN_TEST(testRoomGetOpenTime);
	RUN_TEST(testRoomGetCloseTime);
	RUN_TEST(testRoomGetDifficulty);
	RUN_TEST(testRoomNewReservation);
	RUN_TEST(testRoomHasReservations);
	RUN_TEST(testRoomEarns);
	RUN_TEST(testRoomNextDay);
	RUN_TEST(testRoomCopy);
	RUN_TEST(testRoomDestroy);
	RUN_TEST(testRoomTodaysReservations);
	RUN_TEST(testRoomGetReservationInTime);//!!!!!!!!
	RUN_TEST(testRoomCalculatedScore);
	return 0;
}
