#include <stdio.h>
#include <assert.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include "test_utilities.h"
#include "../Company.h"
#include "../Room.h"
#include "../mtm_ex3.h"


static bool testCompanyCreate() {
	CompanyResult result;
	ASSERT_TEST(companyCreate(&result, "matam.technion", MEDICINE) == NULL);
	ASSERT_TEST(result == COMPANY_INVALID_PARAMETER);
	ASSERT_TEST(companyCreate(&result, NULL, COMPUTER_SCIENCE) == NULL);
	ASSERT_TEST(result == COMPANY_NULL_PARAMETER);
	ASSERT_TEST(companyCreate(NULL, "matam@technion@ac.il", MEDICINE) == NULL);
	ASSERT_TEST(companyCreate(NULL, "matam@technion.ac.il", -1) == NULL);
	ASSERT_TEST(companyCreate(NULL, "matam@technion.ac.il", UNKNOWN) == NULL);
	Company company = companyCreate(&result, "matam@technion.ac.il", MEDICINE);
	ASSERT_TEST(result == COMPANY_SUCCESS);
	ASSERT_TEST(company != NULL);
	companyDestroy(company);
	return true;
}
static bool testCompanyDestroy() {
	Company company1 = companyCreate(NULL, "matam.technion", MEDICINE);
	ASSERT_TEST(companyDestroy(company1) == COMPANY_NULL_PARAMETER);
	Company company2 = companyCreate(NULL, "matam@technion@ac.il", MEDICINE);
	ASSERT_TEST(companyDestroy(company2) == COMPANY_NULL_PARAMETER);
	Company company3 = companyCreate(NULL, "matam@technion", -1);
	ASSERT_TEST(companyDestroy(company3) == COMPANY_NULL_PARAMETER);
	Company company4 = companyCreate(NULL, "matam@technion.ac.il", MEDICINE);
	ASSERT_TEST(companyDestroy(company4) == COMPANY_SUCCESS);
	return true;
}

static bool testCompanyCopy() {
	char* email = NULL;
	TechnionFaculty faculty = UNKNOWN;
	int amount = -1;
	Company company = companyCreate(NULL, "matam.technion", MEDICINE);
	ASSERT_TEST(companyCopy(company) == NULL);
	company = companyCreate(NULL, "matam@technion@", MEDICINE);
	ASSERT_TEST(companyCopy(company) == NULL);
	company = companyCreate(NULL, "matam@technion", -1);
	ASSERT_TEST(companyCopy(company) == NULL);
	company = companyCreate(NULL, "matam@technion", UNKNOWN);
	ASSERT_TEST(companyCopy(company) == NULL);
	company = companyCreate(NULL, "matam@technion", MEDICINE);
	companyNewRoom(company, 43, 40, 3, 5, "08-20");
	companyNewRoom(company, 34, 20, 2, 9, "14-23");
	Company company_copy = companyCopy(company);
	ASSERT_TEST(company_copy!= NULL);
	companyGetEmail(company_copy, &email);
	companyGetFaculty(company_copy, &faculty);
	companyRoomsAmount(company_copy, &amount);
	ASSERT_TEST(strcmp(email, "matam@technion") == 0);
	ASSERT_TEST(faculty == MEDICINE);
	ASSERT_TEST(amount == 2);
	companyDestroy(company_copy);
	companyDestroy(company);
	return true;
}

static bool testCompanyGetFaculty() {
	TechnionFaculty faculty = 0;
	Company company = companyCreate(NULL, "matam.technion", MEDICINE);
	ASSERT_TEST(companyGetFaculty(company, &faculty) == COMPANY_NULL_PARAMETER);
	companyDestroy(company);
	company = companyCreate(NULL, "matam@technion@", MEDICINE);
	ASSERT_TEST(companyGetFaculty(company, &faculty) == COMPANY_NULL_PARAMETER);
	companyDestroy(company);
	company = companyCreate(NULL, "matam@technion", -1);
	ASSERT_TEST(companyGetFaculty(company,&faculty) == COMPANY_NULL_PARAMETER);
	companyDestroy(company);
	company = companyCreate(NULL, "matam@technion", MEDICINE);
	ASSERT_TEST(companyGetFaculty(company, &faculty) == COMPANY_SUCCESS);
	ASSERT_TEST(faculty == MEDICINE);
	companyDestroy(company);
	return true;
}

static bool testCompanyGetEmail() {
	char* email;
	Company company = companyCreate(NULL, "matam.technion", MEDICINE);
	ASSERT_TEST(companyGetEmail(company, &email) == COMPANY_NULL_PARAMETER);
	companyDestroy(company);
	company = companyCreate(NULL, "matam@technion@", MEDICINE);
	ASSERT_TEST(companyGetEmail(company, &email) == COMPANY_NULL_PARAMETER);
	companyDestroy(company);
	company = companyCreate(NULL, "matam@technion", -1);
	ASSERT_TEST(companyGetEmail(company,&email) == COMPANY_NULL_PARAMETER);
	companyDestroy(company);
	company = companyCreate(NULL, "matam@technion", MEDICINE);
	ASSERT_TEST(companyGetEmail(company, &email) == COMPANY_SUCCESS);
	ASSERT_TEST(strcmp(email, "matam@technion")==0);
	companyDestroy(company);
	return true;
}

static bool testCompanyNewRoom() {
	Company company = companyCreate(NULL, "Barvazdaz@quack", BIOLOGY);
	int amount = 0;
	ASSERT_TEST(companyNewRoom(company, 43, 40, 3, 5, "08-20") ==
	COMPANY_SUCCESS);
	companyRoomsAmount(company, &amount);
	ASSERT_TEST(amount == 1);
	ASSERT_TEST(companyNewRoom(company, 43, 40, 2, 2, "05-19") ==
	COMPANY_ROOM_ID_EXISTS);
	ASSERT_TEST(companyNewRoom(company, 43, 39, 2, 2, "05-19") ==
	COMPANY_INVALID_PARAMETER);
	companyRoomsAmount(company, &amount);
	ASSERT_TEST(amount == 1);
	companyDestroy(company);
	return true;
}

static bool testCompanyGetRoom() {
	Company company = companyCreate(NULL, "Barvazdaz@quack", BIOLOGY);
	companyNewRoom(company, 43, 40, 3, 5, "08-20");
	Room room = NULL;
	ASSERT_TEST(companyGetRoom(company, &room, 43) == COMPANY_SUCCESS);
	int price = 0;
	roomGetPrice(room, &price);
	ASSERT_TEST(price == 40);
	ASSERT_TEST(companyGetRoom(company, &room, 34) == COMPANY_ILLEGAL_ID);
	companyDestroy(company);
	return true;
}

static bool testCompanyRemoveRoom() {
	Company company = companyCreate(NULL, "Barvazdaz@quack", BIOLOGY);
	int amount = 0;
	companyNewRoom(company, 43, 40, 3, 5, "08-20");
	ASSERT_TEST(companyRemoveRoom(company, -1) == COMPANY_ILLEGAL_ID);
	ASSERT_TEST(companyRemoveRoom(company, 50) == COMPANY_ILLEGAL_ID);
	ASSERT_TEST(companyRemoveRoom(company, 43) == COMPANY_SUCCESS);
	companyRoomsAmount(company, &amount);
	ASSERT_TEST(amount == 0);
	companyNewRoom(company, 10, 80, 2, 8, "10-22");
	Room room = NULL;
	companyGetRoom(company, &room, 10);
	Reservation res = reservationCreate(NULL, "1@31", 10, BIOLOGY, 80, 10, 22,
	3, "03-12", false);
	roomNewReservation(room, res);
	ASSERT_TEST(companyRemoveRoom(company, 10)==COMPANY_ROOM_HAS_RESERVATIONS);
	reservationDestroy(res);
	companyDestroy(company);
	return true;
}

static bool testCompanyNextDay() {
	Company company = companyCreate(NULL, "matam.technion", MEDICINE);
	ASSERT_TEST(companyNextDay(company) == COMPANY_NULL_PARAMETER);
	company = companyCreate(NULL, "barvazim@abaita", MEDICINE);
	companyNewRoom(company, 43, 40, 3, 5, "08-20");
	companyNewRoom(company, 999, 4, 2, 1, "06-22");
	Room room1 = NULL, room2 = NULL;
	companyGetRoom(company, &room1, 43);
	companyGetRoom(company, &room2, 999);
	Reservation res1 = reservationCreate(NULL, "1@31", 43, MEDICINE, 40, 8, 20,
	3, "00-10", false);
	Reservation res2 = reservationCreate(NULL, "1@31", 43, MEDICINE, 40, 8, 20,
	3, "00-12", false);
	Reservation res3 = reservationCreate(NULL, "1@31", 43, MEDICINE, 40, 8, 20,
	3, "02-14", false);
	Reservation res4 = reservationCreate(NULL, "1@31", 999, MEDICINE, 4, 6, 22,
	3, "01-10", false);
	roomNewReservation(room1, res1);
	roomNewReservation(room1, res2);
	roomNewReservation(room1, res3);
	roomNewReservation(room2, res4);
	ASSERT_TEST(companyNextDay(company) == COMPANY_SUCCESS);
	ASSERT_TEST(roomHasReservations(room1));
	ASSERT_TEST(roomHasReservations(room2));
	ASSERT_TEST(companyNextDay(company) == COMPANY_SUCCESS);
	ASSERT_TEST(roomHasReservations(room1));
	ASSERT_TEST(!roomHasReservations(room2));
	ASSERT_TEST(companyNextDay(company) == COMPANY_SUCCESS);
	ASSERT_TEST(!roomHasReservations(room1));
	ASSERT_TEST(!roomHasReservations(room2));
	reservationDestroy(res1);
	reservationDestroy(res2);
	reservationDestroy(res3);
	reservationDestroy(res4);
	companyDestroy(company);
	return true;
}

static bool testCompanyRoomsAmount() {
	Company company = companyCreate(NULL, "Barvazdaz@quack", BIOLOGY);
	int amount = -1;
	companyRoomsAmount(company, &amount);
	ASSERT_TEST(amount == 0);
	companyNewRoom(company, 43, 40, 3, 5, "08-20");
	companyRoomsAmount(company, &amount);
	ASSERT_TEST(amount == 1);
	companyNewRoom(company, 50, 39, 3, 5, "08-20");
	companyRoomsAmount(company, &amount);
	ASSERT_TEST(amount == 1);
	companyNewRoom(company, 41, 40, 3, 5, "08-20");
	companyRoomsAmount(company, &amount);
	ASSERT_TEST(amount == 2);
	companyRemoveRoom(company, 43);
	companyRoomsAmount(company, &amount);
	ASSERT_TEST(amount == 1);
	companyRemoveRoom(company, 41);
	companyRoomsAmount(company, &amount);
	ASSERT_TEST(amount == 0);
	companyDestroy(company);
	return true;
}

static bool testCompanyEarns() {
	Company company = companyCreate(NULL, "barvazim@abaita", MEDICINE);
	companyNewRoom(company, 1, 40, 1, 1, "08-20");
	companyNewRoom(company, 24, 36, 3, 5, "06-22");
	Room room1 = NULL, room2 = NULL;
	Reservation res1 = reservationCreate(NULL, "1@31", 1, MEDICINE, 40, 8, 20,
	3, "00-8", false);
	Reservation res2 = reservationCreate(NULL, "1@31", 1, MEDICINE, 40, 8, 20,
	3, "00-10", false);
	Reservation res3 = reservationCreate(NULL, "1@31", 24, MEDICINE, 36, 6, 22,
	4, "02-14", false);
	Reservation res4 = reservationCreate(NULL, "1@31", 24, MEDICINE, 36, 6, 22,
	4, "01-10", false);
	roomNewReservation(room1, res1);
	roomNewReservation(room2, res2);
	roomNewReservation(room1, res3);
	roomNewReservation(room2, res4);
	companyNextDay(company);
	printf("EARNS: %d\n", companyEarns(company));
//	ASSERT_TEST(companyEarns(company) == 80);
	companyNextDay(company);
	printf("EARNS: %d\n", companyEarns(company));
//	ASSERT_TEST(companyEarns(company) == 116);
	companyNextDay(company);
	printf("EARNS: %d\n", companyEarns(company));
//	ASSERT_TEST(companyEarns(company) == 152);
	companyDestroy(company);
	return true;
}

static bool testCompanyTodaysReservations() {
	Company company = companyCreate(NULL, "barvazim@abaita", MEDICINE);
	companyNewRoom(company, 43, 40, 3, 5, "08-20");
	companyNewRoom(company, 999, 4, 2, 1, "06-22");
	Room room1 = NULL, room2 = NULL;
	companyGetRoom(company, &room1, 43);
	companyGetRoom(company, &room2, 999);
	Reservation res1 = reservationCreate(NULL, "1@31", 43, MEDICINE, 40, 8, 20,
	3, "00-10", false);
	Reservation res2 = reservationCreate(NULL, "1@31", 999, MEDICINE, 40, 8, 20,
	3, "00-12", false);
	Reservation res3 = reservationCreate(NULL, "1@31", 999, MEDICINE, 40, 8, 20,
	3, "02-14", false);
	Reservation res4 = reservationCreate(NULL, "1@31", 999, MEDICINE, 4, 6, 22,
	3, "01-10", false);
	roomNewReservation(room1, res1);
	roomNewReservation(room1, res2);
	roomNewReservation(room1, res3);
	roomNewReservation(room2, res4);
	ASSERT_TEST(companyTodaysReservations(company) == 2);
	companyNextDay(company);
	ASSERT_TEST(companyTodaysReservations(company) == 1);
	companyNextDay(company);
	ASSERT_TEST(companyTodaysReservations(company) == 1);
	reservationDestroy(res4);
	companyDestroy(company);
	return true;
}

static bool testCompanyRoomsReserved() {
	Company company = companyCreate(NULL, "barvazim@abaita", MEDICINE);
	companyNewRoom(company, 43, 40, 3, 5, "08-20");
	companyNewRoom(company, 999, 4, 2, 1, "06-22");
	Room room1 = NULL, room2 = NULL;
	companyGetRoom(company, &room1, 43);
	companyGetRoom(company, &room2, 999);
	Reservation res1 = reservationCreate(NULL, "1@31", 43, MEDICINE, 40, 8, 20,
	3, "00-10", false);
	Reservation res2 = reservationCreate(NULL, "1@31", 999, MEDICINE, 40, 8, 20,
	3, "00-12", false);
	Reservation res4 = reservationCreate(NULL, "1@31", 999, MEDICINE, 4, 6, 22,
	3, "01-10", false);
	roomNewReservation(room1, res1);
	roomNewReservation(room1, res2);
	roomNewReservation(room2, res4);
	ASSERT_TEST(companyRoomsReserved(company) == true);
	companyNextDay(company);
	ASSERT_TEST(companyRoomsReserved(company) == true);
	companyNextDay(company);
	ASSERT_TEST(companyRoomsReserved(company) == false);
	companyDestroy(company);
	return true;
}

static bool testCompanyLowestIdRoomNextRoom() {
	int id = 0;
	Company company = companyCreate(NULL, "barvazim@abaita", MEDICINE);
	companyNewRoom(company, 43, 40, 3, 5, "08-20");
	companyNewRoom(company, 99, 8, 4, 1, "06-22");
	Room room = companyLowestIdRoom(company, &id);
	roomGetId(room, &id);
	ASSERT_TEST(id == 43);
	companyNewRoom(company, 25, 4, 2, 1, "06-22");
	room = companyLowestIdRoom(company, &id);
	roomGetId(room, &id);
	ASSERT_TEST(id == 25);
	room = companyNextRoom(company, &id);
	ASSERT_TEST(id == 43);
	companyDestroy(company);
	return true;
}


int main(int argv, char** arc) {
	RUN_TEST(testCompanyCreate);
	RUN_TEST(testCompanyGetEmail);
	RUN_TEST(testCompanyGetFaculty);
	RUN_TEST(testCompanyNewRoom);
	RUN_TEST(testCompanyRoomsAmount);
	RUN_TEST(testCompanyGetRoom);
	RUN_TEST(testCompanyRemoveRoom);
	RUN_TEST(testCompanyNextDay);
	RUN_TEST(testCompanyEarns);
	RUN_TEST(testCompanyTodaysReservations);
	RUN_TEST(testCompanyRoomsReserved);
	RUN_TEST(testCompanyLowestIdRoomNextRoom);
	RUN_TEST(testCompanyCopy);
	RUN_TEST(testCompanyDestroy);
	return 0;
}
